-- SET NAMES utf8mb4;
-- SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
-- SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
-- SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';

-- Above code is taken from Sakila sample schema creation file.

DROP SCHEMA IF EXISTS loandb;
CREATE SCHEMA loandb;
USE loandb;

DROP TABLE IF EXISTS customer;

CREATE TABLE customer(
customer_id int,
name varchar(40),
age int,
address text,
region_code text,
region text,
phone text,
email varchar(50),
income int,
credit_score int,
employment_status varchar(30),
risk_category varchar(30),
customer_since date,
active_loans int,
--primary key(customer_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Load the data into the table and then set primary key.

DROP TABLE IF EXISTS loan_data;

CREATE TABLE loan_data(
loan_id int,
customer_id int,
loan_amount int,
loan_date date,
loan_status varchar(40),
repayment_history int,
interest_rate int,
loan_purpose varchar(40),
collateral varchar(40),
default_rise varchar(40), 
--primary key(loan_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

-- Load the data into the table and then set primary key.

ALTER TABLE `loandb`.`load_data` 
CHANGE COLUMN `loan_id` `loan_id` INT NOT NULL ,
ADD PRIMARY KEY (`loan_id`);
;



DROP TABLE IF EXISTS transaction;

CREATE TABLE transaction (
transaction_id int,
loadn_id int,
customer_id int,
transaction_date DATETIME,
transaction_amount int,
transaction_type varchar(40),
payment_method varchar(40),
status varchar(40),
remarks varchar(40),
--PRIMARY KEY (transaction_id)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4;

ALTER TABLE `loandb`.`transaction` 
CHANGE COLUMN `transaction_id` `transaction_id` INT NOT NULL ,
ADD PRIMARY KEY (`transaction_id`);
;


-- Load the data into the table and then set primary key.

-- Creating table -> import data into table.
-- Note: Adding Primany key is important. Once Primary key is set then set FOREIGN key
-- Use below code to set for each table.

ALTER TABLE `loandb`.`loan_data` 
ADD INDEX `FK1+Cust_id_idx` (`customer_id` ASC) VISIBLE;
;
ALTER TABLE `loandb`.`loan_data` 
ADD CONSTRAINT `FK1+Cust_id`
  FOREIGN KEY (`customer_id`)
  REFERENCES `loandb`.`customer` (`customer_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

-- Second table update 
ALTER TABLE `loandb`.`transaction` 
ADD INDEX `FK2_LID_idx` (`loadn_id` ASC) VISIBLE;
;
ALTER TABLE `loandb`.`transaction` 
ADD CONSTRAINT `FK2_LID`
  FOREIGN KEY (`loadn_id`)
  REFERENCES `loandb`.`loan_data` (`loan_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

-- third table udpate

ALTER TABLE `loandb`.`transaction` 
ADD INDEX `FK3_cid_idx` (`customer_id` ASC) VISIBLE;
;
ALTER TABLE `loandb`.`transaction` 
ADD CONSTRAINT `FK3_cid`
  FOREIGN KEY (`customer_id`)
  REFERENCES `loandb`.`customer` (`customer_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

-- End of the schema_table file.


