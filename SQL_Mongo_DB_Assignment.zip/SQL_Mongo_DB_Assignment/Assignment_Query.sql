use loandb;
-- 1) Customer Risk Analysis: Identify customers with low credit scores and high-risk loans to predict 
--     potential defaults and prioritize risk mitigation strategies.
-- SELECT * -- get all the customer data
SELECT c.customer_id, c.name, c.credit_score, l.loan_id, l.loan_amount 
FROM customer c JOIN loan_data l ON c.customer_id = l.customer_id
WHERE c.credit_score < (SELECT AVG(c.credit_score) from customer c) AND l.default_rise = 'High' -- either use number 570 or use nested query.
ORDER BY c.credit_score ASC, l.loan_amount DESC;

-- 2) Loan Purpose Insights: Determine the most popular loan purposes and their associated 
-- revenues to align financial products with customer demands.

SELECT l.loan_purpose, COUNT(l.loan_id) AS total_loans, SUM(l.loan_amount) AS total_revenue FROM Loan_data l
GROUP BY l.loan_purpose ORDER BY total_loans DESC, total_revenue DESC;

-- 3) High-Value Transactions: Detect transactions that exceed 30% of their respective loan amounts 
-- to flag potential fraudulent activities.


SELECT t.transaction_id, t.loadn_id, t.customer_id, t.transaction_amount, l.loan_amount, 
(t.transaction_amount / l.loan_amount) * 100 AS transaction_percentage
FROM transaction t JOIN loan_data l ON t.loadn_id = l.loan_id
WHERE (t.transaction_amount / l.loan_amount) > 0.30 ORDER BY transaction_percentage DESC;

-- 4) Missed EMI Count: Analyze the number of missed EMIs per loan to identify loans at risk of 
-- default and suggest intervention strategies.

SELECT l.loan_id, l.customer_id, l.loan_amount, COUNT(t.transaction_id) AS missed_emi_count 
FROM loan_data l LEFT JOIN transaction t ON l.loan_id = t.loadn_id
WHERE t.transaction_type = 'Missed EMI' 
GROUP BY l.loan_id, l.customer_id, l.loan_amount ORDER BY missed_emi_count DESC;

-- 5) Regional Loan Distribution: Examine the geographical distribution of loan disbursements to 
-- assess regional trends and business opportunities.

SELECT c.region, COUNT(l.loan_id) AS total_loans, SUM(l.loan_amount) AS total_disbursed_amount, max(l.loan_amount) as Max_loaned , MIN(l.loan_amount) as Min_loaned,
avg(l.loan_amount) as Average
FROM customer c JOIN loan_data l ON c.customer_id = l.customer_id
GROUP BY c.region ORDER BY total_disbursed_amount DESC;

-- 6) Loyal Customers: List customers who have been associated with Cross River Bank for over five 
-- years and evaluate their loan activity to design loyalty programs. 

SELECT c.customer_id, c.name, c.customer_since, DATEDIFF(CURDATE(), c.customer_since) / 365 AS banking_in_years,
COUNT(l.loan_id) AS total_loans, SUM(l.loan_amount) AS total_loan_amount
FROM customer c JOIN loan_data l ON c.customer_id = l.customer_id
WHERE DATEDIFF(CURDATE(), c.customer_since) >= 5 * 365
GROUP BY c.customer_id, c.name, c.customer_since ORDER BY banking_in_years DESC, total_loan_amount DESC;

-- 7) High-Performing Loans: Identify loans with excellent repayment histories to refine lending 
-- policies and highlight successful products.

SELECT l.loan_id, l.customer_id, l.loan_amount, COUNT(t.transaction_id) AS total_payments, SUM(t.transaction_amount) AS total_paid,
(SUM(t.transaction_amount) / l.loan_amount) * 100 AS repayment_percentage FROM loan_data l
JOIN transaction t ON l.loan_id = t.loadn_id WHERE t.transaction_type = 'EMI Payment' AND t.remarks = 'On-time payment.'
GROUP BY l.loan_id, l.customer_id, l.loan_amount HAVING repayment_percentage >= 90
ORDER BY repayment_percentage DESC;

-- 8) Age-Based Loan Analysis: Analyze loan amounts disbursed to customers of different age groups 
-- to design targeted financial products.

SELECT 
CASE 
	WHEN c.age BETWEEN 18 AND 25 THEN '18-25'
	WHEN c.age BETWEEN 26 AND 35 THEN '26-35'
	WHEN c.age BETWEEN 36 AND 45 THEN '36-45'
	WHEN c.age BETWEEN 46 AND 60 THEN '46-60'
	ELSE '60+'
END AS age_group, COUNT(l.loan_id) AS total_loans, SUM(l.loan_amount) AS total_disbursed_amount, AVG(l.loan_amount) AS avg_loan_amount
FROM customer c JOIN loan_data l ON c.customer_id = l.customer_id
GROUP BY age_group ORDER BY total_disbursed_amount DESC;

-- 9) Seasonal Transaction Trends: Examine transaction patterns over years and months to identify 
-- seasonal trends in loan repayments.

SELECT YEAR(t.transaction_date) AS transaction_year, MONTH(t.transaction_date) AS transaction_month, COUNT(t.transaction_id) AS total_transactions, 
SUM(t.transaction_amount) AS total_repayment_amount FROM transaction t WHERE t.transaction_type = 'EMI Payment'
GROUP BY transaction_year, transaction_month ORDER BY transaction_year DESC, transaction_month ASC;

-- 10) Fraud Detection: Highlight potential fraud by identifying mismatches between customer address 
-- locations and transaction IP locations. Advanced 

SELECT c.customer_id, c.name, c.address AS registered_address, i.ip_address AS transaction_location_ip, i.address AS user_virtuial_location, t.transaction_amount, t.transaction_date FROM customer c
JOIN transaction t ON c.customer_id = t.customer_id join ip_address i on t.customer_id = i.customer_id WHERE c.address <> i.address
ORDER BY t.transaction_date DESC;

-- 11) Repayment History Analysis: Rank loans by repayment performance using window functions. 
-- Advanced 

SELECT l.loan_id, l.customer_id, l.loan_amount, SUM(t.transaction_amount) AS total_paid, (SUM(t.transaction_amount) / l.loan_amount) * 100 AS repayment_percentage,
RANK() OVER (ORDER BY (SUM(t.transaction_amount) / l.loan_amount) DESC) AS repayment_rank FROM loan_data l
JOIN transaction t ON l.loan_id = t.loadn_id WHERE t.transaction_type = 'EMI Payment'
GROUP BY l.loan_id, l.customer_id, l.loan_amount ORDER BY repayment_rank;

-- 12) Credit Score vs. Loan Amount: Compare average loan amounts for different credit score ranges.

SELECT 
CASE 
	WHEN c.credit_score >= 750 THEN 'Excellent (750+)'
	WHEN c.credit_score BETWEEN 650 AND 749 THEN 'Good (650-749)'
	WHEN c.credit_score BETWEEN 550 AND 649 THEN 'Fair (550-649)'
	ELSE 'Poor (<550)'
END AS credit_score_category, COUNT(l.loan_id) AS total_loans, AVG(l.loan_amount) AS avg_loan_amount, SUM(l.loan_amount) AS total_disbursed_amount
FROM customer c JOIN loan_data l ON c.customer_id = l.customer_id
GROUP BY credit_score_category ORDER BY avg_loan_amount DESC;

-- 13) Top Borrowing Regions: Identify regions with the highest total loan disbursements

SELECT c.customer_id, c.region_code, c.region, COUNT(l.loan_id) AS total_loans, SUM(l.loan_amount) AS total_disbursed_amount
FROM customer c JOIN loan_data l ON c.customer_id = l.customer_id
GROUP BY c.customer_id ORDER BY total_disbursed_amount DESC LIMIT 3;

-- 14) Early Repayment Patterns: Detect loans with frequent early repayments and their impact on revenue. Method 1: 

-- SELECT l.loan_id, l.customer_id, l.loan_amount, SUM(t.transaction_amount) AS total_early_repayment,
-- (SUM(t.transaction_amount) / l.loan_amount) * 100 AS early_repayment_percentage, 
-- (l.loan_amount * 0.18) AS estimated_interest_loss, -- Current loan at 18% interest rate
-- COUNT(MONTH(t.transaction_date)) as total_month_passed
-- FROM loan_data l JOIN transaction t ON l.loan_id = t.loadn_id WHERE l.loan_status = 'closed' and t.transaction_type = 'Prepayment'
-- GROUP BY l.loan_id, l.customer_id, l.loan_amount ORDER BY total_month_passed DESC;

-- Below code logic is comparing supposed payment in months from start date to toatl payment so far done.
-- differentce between these dates tells percentage loss by successful prepayments for loan staus as closed.

-- select l.loan_id, sum(month(t.transaction_date)) as totalmonth, timestampdiff(month,t.transaction_date,curdate()) as supposed_payment_count,
-- (sum(month(t.transaction_date)) - timestampdiff(month,t.transaction_date,curdate())) * 0.18 as actual_loss
-- from loan_data l join transaction t on l.loan_id = t.loadn_id where l.loan_status = 'closed' and t.transaction_type = 'Prepayment'
-- group by l.loan_id, t.transaction_date order by totalmonth desc;

-- we can take number of months to close the loan applied logic is based on that bank wants loan to continue till today curdate() as well.

select l.loan_id, month(l.loan_date) as start_month, timestampdiff(month,l.loan_date,curdate()) as supposed_payment_count, l.loan_status as current_status
,(select timestampdiff(month,t.transaction_date,l.loan_date) where l.loan_status = 'closed' and t.transaction_type = 'Prepayment') as loan_duration,
(select abs(loan_duration - supposed_payment_count)* 0.18) as int_loss_months -- difference for 18 % loan
from loan_data l join transaction t ON l.loan_id = t.loadn_id where l.loan_status = 'closed' and t.transaction_type = 'Prepayment' order by int_loss_months desc limit 5;


-- Count early repayment vs others and check impact on interest

-- SELECT CASE WHEN repayment_history <= 3 THEN 'Early Repayment' ELSE 'Regular/Long Term' END AS repayment_type,
-- COUNT(*) AS loan_count, AVG(interest_rate) AS avg_interest_rate, AVG(loan_amount) AS avg_loan_amount
-- FROM loan_data GROUP BY repayment_type;

-- 15) Feedback Correlation: Correlate customer feedback sentiment scores with loan statuses.

SELECT l.loan_status as Active_Status, f.feedback_category, MAX(f.sentiment_score) AS max_sentiment_score, MiN(f.sentiment_score) AS min_score, COUNT(l.loan_id) AS total_loans, 
SUM(CASE WHEN l.default_rise = 'High' THEN 1 ELSE 0 END) AS high_risk_loans
FROM feedback f JOIN loan_data l ON f.loan_id = l.loan_id
GROUP BY f.feedback_category,l.loan_status ORDER BY max_sentiment_score,min_score DESC;s



