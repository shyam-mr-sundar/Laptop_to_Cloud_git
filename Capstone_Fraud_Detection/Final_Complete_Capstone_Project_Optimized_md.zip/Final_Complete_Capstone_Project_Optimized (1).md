#### The Following are the Drawbacks in the 'Capstone Project JP Morgan Chase Dataset' project
> We have not done complete EDA

> By applying SMOTE (To make data balancing), our training dataset become 5+ million rows to 10+ million rows

> Due to this, models like 'RandomForest, Randomized Search CV, and XGBoost' are demanding more Computational Power and DiskSpace.

> Still have some amount of False Negitives(4), and False Positives(11795) for Hybrid Logistic Regression with Precision 12% only

> In Hybrid XGBoost model we have more False Negitives(33), and Less False Positives(492) with the Precision of 77%

> So our new model must have to take less computing resources, and less diskspace.

### Agenda
- Reduce the False Negitives from 33 to 0 (if Possible)
- Reduce the False positives (as much as posible)
- Use-less computational Power to run the models
- Use-less diskspace to run the models
- From the internet and Stack Overflow it is suggested 'to Detect realworld fraud in Banking Transactions. To do that we must need Historical data.
- Supervised Learning models mostly use Historical data, it means we can have train data. The Fraud Patterns in the train data can be helpful for us to detect frauds patterns in test data.
- Due to this reason, we are using Supervised Learning models in Hybrid Machine Learning models, for better Precision and Recall scores.

### 1. Importing Libraries


```python
# Import Libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score, f1_score, recall_score, precision_score, confusion_matrix, classification_report, ConfusionMatrixDisplay)
from sklearn. preprocessing import StandardScaler

# Read the CSV file
file_path = r"C:\Users\SMangal\Downloads\Cap1\Fraud detection JP Morgan\Fraud Detection System for JPMorgan Chase _log.csv"
df = pd.read_csv(file_path)

# Save as Parquet file
parquet_file = "JPMorgan_Dataset.parquet"
df.to_parquet(parquet_file, engine='pyarrow', index=False)

print(f"CSV file is converted to save fast readability using Parquet: {parquet_file}")

df = pd.read_parquet(r"C:\Users\SMangal\Downloads\Cap1\Fraud detection JP Morgan\JPMorgan_Dataset.parquet")
df.head()
```

    CSV file is converted to save fast readability using Parquet: JPMorgan_Dataset.parquet
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>step</th>
      <th>type</th>
      <th>amount</th>
      <th>nameOrig</th>
      <th>oldbalanceOrg</th>
      <th>newbalanceOrig</th>
      <th>nameDest</th>
      <th>oldbalanceDest</th>
      <th>newbalanceDest</th>
      <th>isFraud</th>
      <th>isFlaggedFraud</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>PAYMENT</td>
      <td>9839.64</td>
      <td>C1231006815</td>
      <td>170136.0</td>
      <td>160296.36</td>
      <td>M1979787155</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>PAYMENT</td>
      <td>1864.28</td>
      <td>C1666544295</td>
      <td>21249.0</td>
      <td>19384.72</td>
      <td>M2044282225</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>TRANSFER</td>
      <td>181.00</td>
      <td>C1305486145</td>
      <td>181.0</td>
      <td>0.00</td>
      <td>C553264065</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>CASH_OUT</td>
      <td>181.00</td>
      <td>C840083671</td>
      <td>181.0</td>
      <td>0.00</td>
      <td>C38997010</td>
      <td>21182.0</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>PAYMENT</td>
      <td>11668.14</td>
      <td>C2048537720</td>
      <td>41554.0</td>
      <td>29885.86</td>
      <td>M1230701703</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



### 2. Data Exploring


```python
# Check the Shape of Dataframe
df_shape = df.shape
```


```python
# Check the information of the DataFrame
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 6362620 entries, 0 to 6362619
    Data columns (total 11 columns):
     #   Column          Dtype  
    ---  ------          -----  
     0   step            int64  
     1   type            object 
     2   amount          float64
     3   nameOrig        object 
     4   oldbalanceOrg   float64
     5   newbalanceOrig  float64
     6   nameDest        object 
     7   oldbalanceDest  float64
     8   newbalanceDest  float64
     9   isFraud         int64  
     10  isFlaggedFraud  int64  
    dtypes: float64(5), int64(3), object(3)
    memory usage: 534.0+ MB
    


```python
# Check columns
cols = df.columns.to_list()
print(cols,df_shape)
```

    ['step', 'type', 'amount', 'nameOrig', 'oldbalanceOrg', 'newbalanceOrig', 'nameDest', 'oldbalanceDest', 'newbalanceDest', 'isFraud', 'isFlaggedFraud'] (6362620, 11)
    

### **Observations**
- Total we have 6.3 Million Rows(approx) with the 11 columns
- in dataframe we have string data columns 3 (type, nameOrig, nameDest) and remaininig all columns are numerical columns

## 3. Data-Preprocessing

### 3.1 Data Cleaning


```python
# Check Null values in DataFrame
df.isnull().sum()
```




    step              0
    type              0
    amount            0
    nameOrig          0
    oldbalanceOrg     0
    newbalanceOrig    0
    nameDest          0
    oldbalanceDest    0
    newbalanceDest    0
    isFraud           0
    isFlaggedFraud    0
    dtype: int64




```python
# Check Duplicates
df.duplicated().sum()
```




    np.int64(0)



### **Observations**
- In our dataset we don't have any null values
- In our dataset we don't have duplicate values/rows also
- Tip : Hover mouse curser and press Ctrl key twice on the keyboard to get better view of plots

### 3.2 Understanding the data by using the charts


```python
# 1. Transaction Type vs Fraud: Bar Chart
sns.countplot(x = 'type', hue = 'isFraud', data = df)
plt.title("Transaction Type vs Fraud")
plt.show()
```


    
![png](output_15_0.png)
    



```python
# 2. Transaction type vs amount: Boxplot
sns.boxplot(x = 'type', y = 'amount', data = df)
plt.title("distribution of Amount by Type")
plt.show()
```


    
![png](output_16_0.png)
    



```python
# 3. Fraud vs Amount: Boxplot
sns.boxplot(x = 'isFraud', y = 'amount', data = df)
plt.title("Fradulant vs Non-Fraudulant transactions")
plt.show()
```


    
![png](output_17_0.png)
    


### **Observations**
- **Chart 1**: We can see more transactions are Cashout type, and in graph we are unable to see the Fraud Transaction count, because the Fraud rate is very less
- **Chart 2**: We can see more outliers are in the 'transfer' type of Transactions
- **Chart 3**: In this chart we can observe that Non_Fraud Transactions have more Outliers, and Fraud transactions also have outliers


```python
# 4. Amount vs Old Balance orig: Scatter Plot
plt.scatter(df['amount'], df['oldbalanceOrg'], alpha = 0.5)
plt.xlabel('Amount')
plt.ylabel('Old Balance Orig')
plt.title("Amount vs Old Balance Orig")
plt.show()
```


    
![png](output_19_0.png)
    



```python
# 5. Old Balance Orig vs New Balance Oreig: Scatter plot
plt.figure(figsize = (8, 6))
plt.scatter(df['oldbalanceOrg'], df['newbalanceOrig'], alpha = 0.5)
plt.xlabel("Old Balance Orig")
plt.ylabel("New Balance Orig")
plt.title("Old Balance Orig vs New Balance Orig")
plt.tight_layout()
plt.show()
```


    
![png](output_20_0.png)
    



```python
# 6. isFlaggedFraud vs Amount: Bar Plot
sns.barplot(x = 'isFlaggedFraud', y = 'amount', data = df, errorbar=None)
plt.title("Flagged Fraud Amounts")
plt.show()
```


    
![png](output_21_0.png)
    


### **Observations**
- **Chart 4**: This chart shows that most transactions have either a low amount or low originating balance, but there are a few transactions with extremely high values for both. These extreme points suggest the presence of significant outliers in your data.
- **Chart 5**: This chart shows that the new balance of the originator is strongly correlated with the old balance, forming a linear pattern. Most transactions result in a reduction of balance, and very few points deviate from this trend, suggesting typical transaction behavior without many anomalies.
- **Chart 6**: This chart reveals that transactions flagged as fraud involve much higher total amounts compared to those not flagged. It suggests that the fraud detection system mainly targets large-scale transactions.


```python
# 7. Step vs IsFraud: Line plot
step_fraud = df.groupby('step')['isFraud'].sum()
step_fraud.plot(kind = 'line')
plt.xlabel("Step")
plt.ylabel("Number of Frauds")
plt.title("Fraud Incidents over the time")
plt.show()
```


    
![png](output_23_0.png)
    



```python
# 8. Transaction type distribution: PIE Chart
type_counts = df['type'].value_counts()
type_counts.plot(kind = 'pie', autopct = '%1.1f%%')
plt.title("Transaction type distribution")
plt.ylabel('')
plt.show()
```


    
![png](output_24_0.png)
    



```python
# 9. Violin Plot: Amount across types
sns.violinplot(x = 'type', y = 'amount', data = df)
plt.title("Amount Distribution by Type")
plt.show()
```


    
![png](output_25_0.png)
    


### Observations
- **Chart 7**: Chart shows that the number of fraud incidents fluctuates over different time steps without a clear upward or downward trend. Fraud occurrences are spread fairly evenly, suggesting no specific temporal patterns or spikes.
- **Chart 8**: In this pie chart we can see more number of Transactions comes under the 'Cashout_type', and after this 'Payment' respectively
- **Chart 9**: This violin chart shows that transaction amounts vary greatly by type, with "TRANSFER" and "CASH_OUT" having the widest range and extreme outliers. Most transaction types have many small values, but a few very large amounts, especially for transfers.


```python
# 10. Amount split by isFraud
sns.histplot(data = df, x = 'amount', hue = 'isFraud', bins = 50, kde = True)
plt.title("Amount distribution by Fraud")
plt.show()
```


    
![png](output_27_0.png)
    



```python
# 11. Old Balance for Fraud and non-Fraud cases: KDE Plot
sns.kdeplot(df[df['isFraud'] == 1]['oldbalanceOrg'], label = 'Fraud', fill = True)
sns.kdeplot(df[df['isFraud'] == 0]['oldbalanceOrg'], label = 'Not Fraud', fill = True)
plt.title("Old balance distribution by Fraud Status")
plt.legend()
plt.show()
```


    
![png](output_28_0.png)
    



```python
num_cols = df.select_dtypes('int64','float64').columns.to_list()
num_cols
```




    ['step', 'isFraud', 'isFlaggedFraud']




```python
# 12. We can Do Histogram to know Relationship between the Numerical columns based on sample values from each columns
numeric_cols = ['step','amount','oldbalanceOrg','newbalanceOrig','oldbalanceDest','newbalanceDest']

# Selecting the above columns fromt the actual DataFrame
corr = df[numeric_cols].corr()

# Plot the heatmap
plt.figure(figsize = (16, 12))
sns.heatmap(corr, annot = True, fmt = '.2f', cmap = 'coolwarm')
plt.title('Correlation Heatmap with the encoded transaction types')
plt.tight_layout()
plt.show()
```


    
![png](output_30_0.png)
    


### Observations
- **Chart 10**: This chart shows that most transactions, including both fraud and non-fraud, have low amounts, but there are occasional very large amounts, indicating significant outliers especially among non-fraud cases. The count of low-value transactions is overwhelmingly high.
- **Chart 11**: Most transactions, whether fraudulent or not, originate from accounts with low balances, but fraudulent transactions tend to come from accounts with slightly higher old balances.
- **Chart 12**: In the heatmap we can see 'New Balance Orig' is highly correlated with the 'Old Balance Org' and 'New Balance Dest' is highly correlated with the 'Old Balance Dest'

### 3.3 Checking Outliers
#### Check Outliers in the Numeric columns using box plot


```python
# Define a numeric columns
numeric_cols = ['step','amount','oldbalanceOrg','newbalanceOrig','oldbalanceDest','newbalanceDest']

# Set Seaborn style
sns.set(style = 'whitegrid')

# Calculate grid size 2 columns
n_cols = 2
n_rows = int(np.ceil(len(numeric_cols) / n_cols))

# Create a Figure
plt.figure(figsize = (8, 6 * n_rows))

for i, col in enumerate(numeric_cols, 1):
    Q1 = df[col].quantile(0.25)
    Q3 = df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    outlier_count = df[(df[col] < lower_bound) | (df[col] > upper_bound)].shape[0]

    # Create a boxplot
    plt.subplot(n_rows, n_cols, i)
    sns.boxplot(data = df, y = col, color = 'skyblue', width = 0.4)
    plt.title(f"{col}\Outliers: {outlier_count}", fontsize = 11)
    plt.xlabel('')
    plt.ylabel('')
    plt.grid(True)

# Adjust layout
plt.tight_layout()
plt.show()
```

    <>:25: SyntaxWarning: invalid escape sequence '\O'
    <>:25: SyntaxWarning: invalid escape sequence '\O'
    C:\Users\SMangal\AppData\Local\Temp\ipykernel_8060\877137286.py:25: SyntaxWarning: invalid escape sequence '\O'
      plt.title(f"{col}\Outliers: {outlier_count}", fontsize = 11)
    


    
![png](output_33_1.png)
    


### Observations
- From the above boxplots shows there is Extreme Outliers in the Numerical columns called
  > 'Step','Amount','OldBalanceOrg','NewBalanceOrig','OldBalanceDest','NewBalanceDest'

- We can plot the Histograms of these numeric columns to understand 'How data was distributed in these columns'


```python
# Now we can plot Histograms to cross validate the above boxplots
# We can use the same numeric cols df for plotting these Histograms
numeric_cols = ['step','amount','oldbalanceOrg','newbalanceOrig','oldbalanceDest','newbalanceDest']

# Set seaborn style
sns.set(style = 'whitegrid')

# Calculate Grid size
n_cols = 2
n_rows = int(np.ceil(len(numeric_cols) / n_cols))

# create a figure
plt.figure(figsize = (8, 6 * n_rows))

# Loop through numeric columns
for i, col in enumerate(numeric_cols, 1):
    plt.subplot(n_rows, n_cols, i)
    plt.hist(df[col], bins = 50)
    plt.title(f'{col} Distribution')
    plt.tight_layout()

plt.show()
```


    
![png](output_35_0.png)
    


### 3.4 Data Processing: Treating Outliers
#### Log Transformation to these 'Step','Amount','OldBalanceOrg','NewBalanceOrig','OldBalanceDest','NewBalanceDest' columns.
> Plotting Histograms before and after 'Log Transformation'


```python
# Set seaborn style for better asthetics
sns.set(style = 'whitegrid')

# List of columns to transform and visualize
cols_to_transform = ['step','amount','oldbalanceOrg','newbalanceOrig','oldbalanceDest','newbalanceDest']

# Step1: Apply Log Transformation to the above column
for col in cols_to_transform:
    df[f'{col}_log'] = np.log1p(df[col])

# Step2: Visualize and Distributions for Comparision
for col in cols_to_transform:
    plt.figure(figsize = (12, 5))

    # Plot the Original Distribution
    plt.subplot(1, 2, 1)
    sns.histplot(df[col], bins = 50, kde = True)
    plt.title(f"Original {col} distribution")

    # Plot for log transformed distribution
    plt.subplot(1, 2, 2)
    sns.histplot(df[f'{col}_log'], bins = 50, kde = True, color = 'orange')
    plt.title(f'Log Tranformed {col} distribution')

    plt.tight_layout()
    plt.show()
```


    
![png](output_37_0.png)
    



    
![png](output_37_1.png)
    



    
![png](output_37_2.png)
    



    
![png](output_37_3.png)
    



    
![png](output_37_4.png)
    



    
![png](output_37_5.png)
    


### Observations
- From the above boxplots, we can Understand the numeric columns 'Step','Amount','OldBalanceOrg','NewBalanceOrig','OldBalanceDest','NewBalanceDest' have the Outliers
- For understanding data distribution, we have plotted Histograms. From the Histograms we can understand, data was distributed towards on left side only(Right Skewed - Right side long tails
- In the above after Log Transformation, we can see data distribution was adjusted to the Center (See the above Log Transformed Histogram)

### 3.5 Feature Engineering


```python
# 1. Balance difference between old balance org and new balance orig
df['orig_balance_diff'] = df['oldbalanceOrg'] - df['newbalanceOrig']
df['dest_balance_diff'] = df['newbalanceDest'] - df['oldbalanceDest']

# 2. Zero balance flags
df['orig_zero_balance_flag'] =  ((df['oldbalanceOrg'] == 0) & (df['newbalanceOrig'] == 0)).astype(int)
df['dest_zero_balance_flag'] = ((df['oldbalanceDest'] == 0) & (df['newbalanceDest'] == 0)).astype(int)

# 3. Transaction type interactions
df['transfer_to_zero_dest'] = ((df['type'] == 'TRANSFER') & (df['newbalanceDest'] == 0)).astype(int)
df['cashout_from_zero_orig'] = ((df['type'] == 'CASH_OUT') & (df['oldbalanceOrg'] == 0)).astype(int)

# 4. Amount to Balance ratio's
df['amount_to_orig_balance_ratio'] = df['amount'] / (df['oldbalanceOrg'] + 1)  # Avoid division by zero
df['amount_to_dest_balance_ratio'] = df['amount'] / (df['oldbalanceDest'] + 1)

# 5. Flag suspicious Patterns
df['suspicious_flag'] = (
    (df['amount'] > 100000) &
    (df['oldbalanceOrg'] == 0) &
    (df['newbalanceOrig'] == 0) &
    (df['type']== 'TRANSFER')
).astype(int)
```


```python
# One hot Encoding
df = pd.get_dummies(df, columns = ['type'], drop_first = True, dtype = int)

# Select only numeric columns for the Correlation heatmap purpose
num_df = df.select_dtypes(include = 'number')

# Compute correlation matrix
corr = num_df.corr()

# Plot the heat map
plt.figure(figsize = (16, 12))
sns.heatmap(corr, annot = True, fmt = '.2f', cmap = 'coolwarm')
plt.title('Correlation Heatmap with the encoded transaction types')
plt.tight_layout()
plt.show()
```


    
![png](output_41_0.png)
    



```python
# Highly correlated columns from the above Heatmap

# Unstack and filter the correlations
corr_pairs = corr.unstack()

# Remove self-correlations and duplicates
corr_pairs = corr_pairs.drop_duplicates().sort_values(ascending=False)

# Filter by correlation thresholds
positive_corr = corr_pairs[corr_pairs > 0.8]

# Negitive Correlation thresholds
negitive_corr = corr_pairs[corr_pairs < -0.8]

# Printing the Outputs
print("Positive Correlated Columns")
print("___________________________________")
print(positive_corr)
print("___________________________________")
print("Negitive Correlated Columns")
print("___________________________________")
print(negitive_corr)
```

    Positive Correlated Columns
    ___________________________________
    step                    step                            1.000000
    oldbalanceOrg           newbalanceOrig                  0.998803
    oldbalanceDest          newbalanceDest                  0.976569
    dest_zero_balance_flag  type_PAYMENT                    0.944407
    amount                  dest_balance_diff               0.845964
                            amount_to_orig_balance_ratio    0.817079
    dtype: float64
    ___________________________________
    Negitive Correlated Columns
    ___________________________________
    Series([], dtype: float64)
    

###### Observations
- We have done feature engineering which can help us to understand different kinds of Amount Transfer patterns, Suddenly account become Empty state Etc
- This Feature Engineering step creates 8 more additional columns, which can help us to understand Fraud Patterns, Those columns are
  > 'Orig_Balance_Diff', 'Dest_Balance_Diff', 'Orig_Zero_Balance_Flag', 'Dest_Zero_Balance_Flag', 'Transfer_To_Zero_Dest', 'Cashout_From_Zero_Orig', 'Amount_To_Orig_Balance_Ratio', 'Amount_To_Dest_Balance_Ratio'
- We have done One-Hot Encoding using pd.get_dummies() for the Column 'type'. Because it is very important column that must we need to do encoding for the Machine Leaning Purpose. The values in the 'type' column is
  > 'TRANSFER', 'CASH_OUT', 'PAYMENT', 'DEBIT', 'CASH_IN'
- After One-Hot Encoding we have done Correlation Heatmap, to understand Correlation between the columns, and We have seggregated Positively correlated and Negitively correlated columns. in that we can see
  > OldBalanceOrg and NewBalanceOrig are highly Correlated Columns
  > OldBalanceDest, and NewBalanceDest
  > Dest_Zero_Balance_Flag  , and type_PAYMENT
- These columns are highly Positively correlated columns

### 3.6 Check data is Ready for Machine Learning models


```python
# Count number of Fraud transactions in isFraud column
num_df['isFraud'].value_counts()
```


```python
print(df.shape)
print(num_df.shape)
```


```python
# Separate numeric columns and string columns
numerical_features = num_df.select_dtypes(include=np.number).columns.tolist()
categorical_features = num_df.select_dtypes(include='object').columns.tolist()
print(numerical_features)
print("__________________________________")
print(categorical_features)
```

### Observations
- We have seen our target variable is Highly Imbalaced in that
  > isFraud column having 0's = 63,54,407 Rows and 1's = 8,213 Rows.
- To Handle this Imbalance, we have previousely used 'SMOTE', but SMOTE made our Training data from 5+ Million Rows to 10+ Million Rows. Due to this the models like 'RandomForest, RandomForest With the Randomized Search CV' are demanding more Computational Power, Due to this Reason we are not doing SMOTE in this Optimized Project
- We can see now actual 'df' becomes 29 columns, but the num_df is having the just 27 Columns. In the num_df we are neglecting 2 categoriocal columns 'nameOrig', and 'nameDest'
- While applying Machine Learing models we are using this **num_df** because it contains numeric columns only

## 4. Machine Learning
> Previously we have worked on RandomForest, and RandomForest with the Randomized Search CV both are taking more Computing Resources, Due to this Reason we are not Considering in this Workbook

### 4.1 Logistic Regression


```python
# 1. Import required modules
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, roc_curve

# 2. Separate Features and target
X = num_df.drop(['isFraud','isFlaggedFraud'], axis = 1)
y = num_df['isFraud']

# 3. Split the data into train and test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 42, stratify = y)

# 4. Initialize and fit the StandardScaler on Training data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)

# 5. Tranform the test data using same scaler
X_test_scaled = scaler.transform(X_test)

# 6. Train Logistic Regression Model
log_model = LogisticRegression()
log_model.fit(X_train_scaled, y_train)

# 7. Make predictions
y_pred = log_model.predict(X_test_scaled)
y_prob = log_model.predict_proba(X_test_scaled)[:, 1]

# 8. Get Evaluations
print("Confusion Matrix\n", confusion_matrix(y_test, y_pred))
print("\nClassification Report\n", classification_report(y_test, y_pred))
print("\nROC-AUC-Curve", roc_auc_score(y_test, y_prob))
```

    Confusion Matrix
     [[1270847      34]
     [    474    1169]]
    
    Classification Report
                   precision    recall  f1-score   support
    
               0       1.00      1.00      1.00   1270881
               1       0.97      0.71      0.82      1643
    
        accuracy                           1.00   1272524
       macro avg       0.99      0.86      0.91   1272524
    weighted avg       1.00      1.00      1.00   1272524
    
    
    ROC-AUC-Curve 0.9886341601257537
    

### Observations
- In Confusion Matrix we can see Logistic Regresion have very less 'False Positives', just 44 only, due to this reason precision got increased, but we can see gradual increase in the 'False Negitives'.
- Here we can understand if 'False Positives' are more, it means legit transactions are flagged as a Fraud. The 'False Negitives' are increased gradually '416'. It means Logistic Regression is unable to detect the Actual Fraud cases.
> In Realworld scenario if our model given more False Positives, it makes Irritating to the Customers. If our model increases 'False Negitves', it means innocent bank customers are effected and lost money due to Fraud happend

### 4.2 Decision Tree Model


```python
from sklearn.tree import DecisionTreeClassifier

# Train Decision Tree Classifier
dt_classifier = DecisionTreeClassifier(criterion = 'gini', max_depth = 10, random_state = 42, class_weight = 'balanced')

# Fit the model
dt_classifier.fit(X_train_scaled, y_train)

# Make Predictions
dt_pred = dt_classifier.predict(X_test_scaled)

# Get evaluation metrics
print("Confusion Matrix\n", confusion_matrix(y_test, dt_pred))
print("\nClassification Report\n", classification_report(y_test, dt_pred))
```

    Confusion Matrix
     [[1270522     359]
     [      5    1638]]
    
    Classification Report
                   precision    recall  f1-score   support
    
               0       1.00      1.00      1.00   1270881
               1       0.82      1.00      0.90      1643
    
        accuracy                           1.00   1272524
       macro avg       0.91      1.00      0.95   1272524
    weighted avg       1.00      1.00      1.00   1272524
    
    

### Observations
- The Decision Tree Model detected Fraud transactions accurately, comparing with the Logistic Regression Model, but Precision was Gradually reduced from 97% to 14%.
- Because Decision tree is good at Detecting actual Fraud cases, but it flagged more number of Legit Transactions as Fraud. This is can make an impact of customer loyality to the Banks.
> Suppose if a person regularly do not exceed his banking transaction not more than 2000.  Suddently he purchased bike, which makes a Big transaction and Bank people maybe consider this transaction as Fraud and due to this reason they hold that user account for sometime.

#### **Support Vector Machine** - It will take more Computing Resources, So we are not using it

### 4.3 Naive Bayes Model


```python
from sklearn.naive_bayes import GaussianNB

# Load the model
nb_classifier = GaussianNB()

# Fit the model
nb_classifier.fit(X_train_scaled, y_train)

# Make predictions
nb_pred = nb_classifier.predict(X_test_scaled)
nb_prob = nb_classifier.predict_proba(X_test_scaled)[:, 1]

# Get evaluation metrics
print("Confusion Matrix\n", confusion_matrix(y_test, nb_pred))
print("\nClassification Report\n", classification_report(y_test, nb_pred))
print("\nROC-AUC-Score\n", roc_auc_score(y_test, nb_prob))
```

    Confusion Matrix
     [[997424 273457]
     [     7   1636]]
    
    Classification Report
                   precision    recall  f1-score   support
    
               0       1.00      0.78      0.88   1270881
               1       0.01      1.00      0.01      1643
    
        accuracy                           0.79   1272524
       macro avg       0.50      0.89      0.45   1272524
    weighted avg       1.00      0.79      0.88   1272524
    
    
    ROC-AUC-Score
     0.9817187314952863
    

### Observations
- In Naive Bayes Model we can see very few number of 'False Negitives' are there. It means we have high 'recall' rate
- This model has increased False Positives (This Model flagged Legitimate Transactions as Fraud) for more than 2.7 Lakhs which is very high, due to this reason, Naive Bayes model precision was become just 1% only

### 4.4 LightGBM Model


```python

```


```python
import lightgbm as lgb

# Find scale weight between Fraud and Non-Fraud transactions
num_negitive = (y_train == 0).sum()
num_positive = (y_train == 1).sum()
scale_pos_weight = num_negitive / num_positive

# Load Model
lgb_classifier = lgb.LGBMClassifier(
    objective = 'binary',
    is_unbalance = False,
    scale_pos_weight = scale_pos_weight,
    metric = 'binary_logloss',
    n_estimators = 100,
    random_state = 42,
    n_jobs = -1
)

# Fit the model
lgb_classifier.fit(X_train_scaled, y_train)

# Make predictions
lgb_pred = lgb_classifier.predict(X_test_scaled)
lgb_prob = lgb_classifier.predict_proba(X_test_scaled)[:, 1]

# Evaluation Metrics
print("Confusion Matrix\n", confusion_matrix(y_test, lgb_pred))
print("\nClassification Report\n", classification_report(y_test, lgb_pred))
print("\nROC-AUC-Score\n", roc_auc_score(y_test, lgb_prob))
print("Scale_pos_weight:", scale_pos_weight)
```

    [LightGBM] [Info] Number of positive: 6570, number of negative: 5083526
    [LightGBM] [Info] Auto-choosing row-wise multi-threading, the overhead of testing was 0.130905 seconds.
    You can set `force_row_wise=true` to remove the overhead.
    And if memory is not enough, you can set `force_col_wise=true`.
    [LightGBM] [Info] Total Bins 2577
    [LightGBM] [Info] Number of data points in the train set: 5090096, number of used features: 19
    [LightGBM] [Info] [binary:BoostFromScore]: pavg=0.001291 -> initscore=-6.651247
    [LightGBM] [Info] Start training from score -6.651247
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    Confusion Matrix
     [[553740 717141]
     [   100   1543]]
    
    Classification Report
                   precision    recall  f1-score   support
    
               0       1.00      0.44      0.61   1270881
               1       0.00      0.94      0.00      1643
    
        accuracy                           0.44   1272524
       macro avg       0.50      0.69      0.31   1272524
    weighted avg       1.00      0.44      0.61   1272524
    
    
    ROC-AUC-Score
     0.6874245145003032
    Scale_pos_weight: 773.7482496194825
    

### Observations
- In the LightGBM we have used, Scale_Pos_Weight, which can be helpful when our Target variable is having Im-Balanced data
- In Scale_Pos_Weight is calculated by deviding the **Number_of_Highest_count_values with the number_of_lowest_count_values** in the target varibale.
- We can use this Multiple Machine learning models like CATBoost, XGBoost.
- In Light Gradient Boost Model (LightGBM) we can see Precision was little increased, when comparing with the Naive Bayes Model.
- Almost half of the False Positives are reduced comparing with the Naive Bayes model, but in Naive Model we can more False Negitives.
- It means Naive Bayes model was unable to predict 21 Fraud transactions.

- #### Below we have increased n_estimators from 100 to 200 and 200 to 400. 
- #### By increasing the n_estimators value, we can see decreasing of Recall value, it means our model is unable to predict the more number of Fraud Cases. 
- #### This is you can understand when you compare the Outputs of LigthGBM 100 Estimators, 200 Estimators, and 400 Estimators respectively.

> **Note**: The below 2 blocks of codes are Optional, that does not make any impact on overall Fraud Detection.

#### Case1: LightGBM with n_estimators = 200


```python
import lightgbm as lgb

# Find scale wait between Fraud and non-Fraud transactions
num_negitive = (y_train == 0).sum()
num_positive = (y_train == 1).sum()
scale_pos_weight = num_negitive / num_positive

# Load model
lgb_classifier = lgb.LGBMClassifier(
    objective = 'binary',
    is_unbalance = False,
    scale_pos_weight = scale_pos_weight,
    metric = 'binary_logloss',
    n_estimators = 200,
    random_state = 42,
    n_jobs = -1
)

# Fit the model
lgb_classifier.fit(X_train_scaled, y_train)

# Make predictions
lgb_pred = lgb_classifier.predict(X_test_scaled)

# Evaluation Metrics
print("Confusion Matrix\n", confusion_matrix(y_test, lgb_pred))
print("\nClassification Report\n", classification_report(y_test, lgb_pred))
```

    [LightGBM] [Info] Number of positive: 6570, number of negative: 5083526
    [LightGBM] [Info] Auto-choosing col-wise multi-threading, the overhead of testing was 0.939586 seconds.
    You can set `force_col_wise=true` to remove the overhead.
    [LightGBM] [Info] Total Bins 4107
    [LightGBM] [Info] Number of data points in the train set: 5090096, number of used features: 25
    [LightGBM] [Info] [binary:BoostFromScore]: pavg=0.001291 -> initscore=-6.651247
    [LightGBM] [Info] Start training from score -6.651247
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    

    C:\Users\SMangal\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\LocalCache\local-packages\Python313\site-packages\sklearn\utils\validation.py:2749: UserWarning: X does not have valid feature names, but LGBMClassifier was fitted with feature names
      warnings.warn(
    

    Confusion Matrix
     [[1259757   11124]
     [    126    1517]]
    
    Classification Report
                   precision    recall  f1-score   support
    
               0       1.00      0.99      1.00   1270881
               1       0.12      0.92      0.21      1643
    
        accuracy                           0.99   1272524
       macro avg       0.56      0.96      0.60   1272524
    weighted avg       1.00      0.99      0.99   1272524
    
    

#### Case2: LightGBM with n_estimators = 400


```python
# Now we can apply LightGBM with n_estimators = 400

# Load model
lgb_classifier = lgb.LGBMClassifier(
    objective = 'binary',
    is_unbalance = False,
    scale_pos_weight = scale_pos_weight,
    metric = 'binary_logloss',
    n_estimators = 400,
    random_state = 42,
    n_jobs = -1
)

# Fit the model
lgb_classifier.fit(X_train_scaled, y_train)

# Make predictions
lgb_pred = lgb_classifier.predict(X_test_scaled)
lgb_prob = lgb_classifier.predict_proba(X_test_scaled)[:, 1]

# Evaluation Metrics
print("Confusion Matrix\n", confusion_matrix(y_test, lgb_pred))
print("\nClassification Report\n", classification_report(y_test, lgb_pred))
print("\nROC-AUC-Score\n", roc_auc_score(y_test, lgb_prob))
```

    [LightGBM] [Info] Number of positive: 6570, number of negative: 5083526
    [LightGBM] [Info] Auto-choosing row-wise multi-threading, the overhead of testing was 0.601392 seconds.
    You can set `force_row_wise=true` to remove the overhead.
    And if memory is not enough, you can set `force_col_wise=true`.
    [LightGBM] [Info] Total Bins 4107
    [LightGBM] [Info] Number of data points in the train set: 5090096, number of used features: 25
    [LightGBM] [Info] [binary:BoostFromScore]: pavg=0.001291 -> initscore=-6.651247
    [LightGBM] [Info] Start training from score -6.651247
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    [LightGBM] [Warning] No further splits with positive gain, best gain: -inf
    [LightGBM] [Warning] Stopped training because there are no more leaves that meet the split requirements
    

    C:\Users\SMangal\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\LocalCache\local-packages\Python313\site-packages\sklearn\utils\validation.py:2749: UserWarning: X does not have valid feature names, but LGBMClassifier was fitted with feature names
      warnings.warn(
    C:\Users\SMangal\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\LocalCache\local-packages\Python313\site-packages\sklearn\utils\validation.py:2749: UserWarning: X does not have valid feature names, but LGBMClassifier was fitted with feature names
      warnings.warn(
    

    Confusion Matrix
     [[1262579    8302]
     [     10    1633]]
    
    Classification Report
                   precision    recall  f1-score   support
    
               0       1.00      0.99      1.00   1270881
               1       0.16      0.99      0.28      1643
    
        accuracy                           0.99   1272524
       macro avg       0.58      0.99      0.64   1272524
    weighted avg       1.00      0.99      1.00   1272524
    
    
    ROC-AUC-Score
     0.9939928708370717
    

### 4.5 CatBoost Model (Category Boost Model)


```python
!pip install catboost
```

    Defaulting to user installation because normal site-packages is not writeable
    Collecting catboost
      Downloading catboost-1.2.8-cp313-cp313-win_amd64.whl.metadata (1.5 kB)
    Collecting graphviz (from catboost)
      Downloading graphviz-0.21-py3-none-any.whl.metadata (12 kB)
    Requirement already satisfied: matplotlib in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from catboost) (3.10.6)
    Requirement already satisfied: numpy<3.0,>=1.16.0 in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from catboost) (2.3.3)
    Requirement already satisfied: pandas>=0.24 in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from catboost) (2.3.2)
    Requirement already satisfied: scipy in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from catboost) (1.16.2)
    Requirement already satisfied: plotly in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from catboost) (6.5.0)
    Requirement already satisfied: six in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from catboost) (1.17.0)
    Requirement already satisfied: python-dateutil>=2.8.2 in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from pandas>=0.24->catboost) (2.9.0.post0)
    Requirement already satisfied: pytz>=2020.1 in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from pandas>=0.24->catboost) (2025.2)
    Requirement already satisfied: tzdata>=2022.7 in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from pandas>=0.24->catboost) (2025.2)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from matplotlib->catboost) (1.3.3)
    Requirement already satisfied: cycler>=0.10 in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from matplotlib->catboost) (0.12.1)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from matplotlib->catboost) (4.60.1)
    Requirement already satisfied: kiwisolver>=1.3.1 in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from matplotlib->catboost) (1.4.9)
    Requirement already satisfied: packaging>=20.0 in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from matplotlib->catboost) (25.0)
    Requirement already satisfied: pillow>=8 in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from matplotlib->catboost) (11.3.0)
    Requirement already satisfied: pyparsing>=2.3.1 in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from matplotlib->catboost) (3.2.5)
    Requirement already satisfied: narwhals>=1.15.1 in c:\users\smangal\appdata\local\packages\pythonsoftwarefoundation.python.3.13_qbz5n2kfra8p0\localcache\local-packages\python313\site-packages (from plotly->catboost) (2.6.0)
    Downloading catboost-1.2.8-cp313-cp313-win_amd64.whl (102.4 MB)
       ---------------------------------------- 0.0/102.4 MB ? eta -:--:--
       ---------------------------------------- 0.5/102.4 MB 10.0 MB/s eta 0:00:11
        --------------------------------------- 2.1/102.4 MB 5.4 MB/s eta 0:00:19
       - -------------------------------------- 2.6/102.4 MB 6.1 MB/s eta 0:00:17
       - -------------------------------------- 3.4/102.4 MB 4.1 MB/s eta 0:00:25
       - -------------------------------------- 4.7/102.4 MB 4.5 MB/s eta 0:00:22
       -- ------------------------------------- 6.3/102.4 MB 5.0 MB/s eta 0:00:20
       -- ------------------------------------- 7.6/102.4 MB 5.3 MB/s eta 0:00:19
       --- ------------------------------------ 9.4/102.4 MB 5.6 MB/s eta 0:00:17
       ---- ----------------------------------- 11.3/102.4 MB 6.0 MB/s eta 0:00:16
       ----- ---------------------------------- 13.4/102.4 MB 6.3 MB/s eta 0:00:15
       ----- ---------------------------------- 14.9/102.4 MB 6.4 MB/s eta 0:00:14
       ------ --------------------------------- 16.3/102.4 MB 6.5 MB/s eta 0:00:14
       ------ --------------------------------- 17.8/102.4 MB 6.5 MB/s eta 0:00:13
       ------- -------------------------------- 19.1/102.4 MB 6.5 MB/s eta 0:00:13
       -------- ------------------------------- 21.0/102.4 MB 6.6 MB/s eta 0:00:13
       -------- ------------------------------- 22.8/102.4 MB 6.8 MB/s eta 0:00:12
       --------- ------------------------------ 24.9/102.4 MB 6.9 MB/s eta 0:00:12
       ---------- ----------------------------- 26.7/102.4 MB 7.0 MB/s eta 0:00:11
       ----------- ---------------------------- 28.8/102.4 MB 7.1 MB/s eta 0:00:11
       ----------- ---------------------------- 30.7/102.4 MB 7.2 MB/s eta 0:00:10
       ------------ --------------------------- 30.9/102.4 MB 7.2 MB/s eta 0:00:10
       ------------ --------------------------- 32.8/102.4 MB 7.0 MB/s eta 0:00:10
       ------------ --------------------------- 32.8/102.4 MB 7.0 MB/s eta 0:00:10
       ------------ --------------------------- 32.8/102.4 MB 7.0 MB/s eta 0:00:10
       ------------ --------------------------- 32.8/102.4 MB 7.0 MB/s eta 0:00:10
       ------------ --------------------------- 32.8/102.4 MB 7.0 MB/s eta 0:00:10
       ------------ --------------------------- 32.8/102.4 MB 7.0 MB/s eta 0:00:10
       ------------ --------------------------- 32.8/102.4 MB 7.0 MB/s eta 0:00:10
       ------------ --------------------------- 32.8/102.4 MB 7.0 MB/s eta 0:00:10
       ------------ --------------------------- 32.8/102.4 MB 7.0 MB/s eta 0:00:10
       ------------ --------------------------- 32.8/102.4 MB 7.0 MB/s eta 0:00:10
       ------------ --------------------------- 32.8/102.4 MB 7.0 MB/s eta 0:00:10
       ------------ --------------------------- 32.8/102.4 MB 7.0 MB/s eta 0:00:10
       ------------- -------------------------- 33.8/102.4 MB 4.7 MB/s eta 0:00:15
       ------------- -------------------------- 35.4/102.4 MB 4.7 MB/s eta 0:00:15
       -------------- ------------------------- 37.0/102.4 MB 4.8 MB/s eta 0:00:14
       --------------- ------------------------ 38.8/102.4 MB 4.9 MB/s eta 0:00:13
       --------------- ------------------------ 40.6/102.4 MB 5.0 MB/s eta 0:00:13
       ---------------- ----------------------- 42.5/102.4 MB 5.1 MB/s eta 0:00:12
       ----------------- ---------------------- 44.3/102.4 MB 5.2 MB/s eta 0:00:12
       ------------------ --------------------- 46.1/102.4 MB 5.3 MB/s eta 0:00:11
       ------------------ --------------------- 48.0/102.4 MB 5.4 MB/s eta 0:00:11
       ------------------- -------------------- 49.8/102.4 MB 5.4 MB/s eta 0:00:10
       -------------------- ------------------- 51.9/102.4 MB 5.5 MB/s eta 0:00:10
       -------------------- ------------------- 53.5/102.4 MB 5.6 MB/s eta 0:00:09
       --------------------- ------------------ 54.8/102.4 MB 5.6 MB/s eta 0:00:09
       ---------------------- ----------------- 56.4/102.4 MB 5.6 MB/s eta 0:00:09
       ---------------------- ----------------- 58.2/102.4 MB 5.7 MB/s eta 0:00:08
       ----------------------- ---------------- 59.5/102.4 MB 5.7 MB/s eta 0:00:08
       ----------------------- ---------------- 60.8/102.4 MB 5.7 MB/s eta 0:00:08
       ------------------------ --------------- 62.4/102.4 MB 5.7 MB/s eta 0:00:07
       ------------------------- -------------- 64.2/102.4 MB 5.8 MB/s eta 0:00:07
       ------------------------- -------------- 65.5/102.4 MB 5.8 MB/s eta 0:00:07
       -------------------------- ------------- 66.8/102.4 MB 5.8 MB/s eta 0:00:07
       -------------------------- ------------- 68.2/102.4 MB 5.8 MB/s eta 0:00:06
       --------------------------- ------------ 69.2/102.4 MB 5.8 MB/s eta 0:00:06
       --------------------------- ------------ 70.3/102.4 MB 5.8 MB/s eta 0:00:06
       --------------------------- ------------ 71.6/102.4 MB 5.8 MB/s eta 0:00:06
       ---------------------------- ----------- 72.9/102.4 MB 5.8 MB/s eta 0:00:06
       ---------------------------- ----------- 73.7/102.4 MB 5.8 MB/s eta 0:00:05
       ----------------------------- ---------- 74.7/102.4 MB 5.7 MB/s eta 0:00:05
       ----------------------------- ---------- 76.0/102.4 MB 5.7 MB/s eta 0:00:05
       ----------------------------- ---------- 76.8/102.4 MB 5.7 MB/s eta 0:00:05
       ------------------------------ --------- 78.1/102.4 MB 5.7 MB/s eta 0:00:05
       ------------------------------- -------- 79.7/102.4 MB 5.7 MB/s eta 0:00:04
       ------------------------------- -------- 80.7/102.4 MB 5.7 MB/s eta 0:00:04
       ------------------------------- -------- 81.5/102.4 MB 5.7 MB/s eta 0:00:04
       -------------------------------- ------- 82.3/102.4 MB 5.7 MB/s eta 0:00:04
       -------------------------------- ------- 83.1/102.4 MB 5.6 MB/s eta 0:00:04
       -------------------------------- ------- 83.9/102.4 MB 5.6 MB/s eta 0:00:04
       --------------------------------- ------ 84.9/102.4 MB 5.6 MB/s eta 0:00:04
       --------------------------------- ------ 86.2/102.4 MB 5.6 MB/s eta 0:00:03
       ---------------------------------- ----- 87.3/102.4 MB 5.6 MB/s eta 0:00:03
       ---------------------------------- ----- 88.3/102.4 MB 5.6 MB/s eta 0:00:03
       ---------------------------------- ----- 89.1/102.4 MB 5.6 MB/s eta 0:00:03
       ----------------------------------- ---- 90.2/102.4 MB 5.6 MB/s eta 0:00:03
       ----------------------------------- ---- 91.5/102.4 MB 5.5 MB/s eta 0:00:02
       ------------------------------------ --- 93.1/102.4 MB 5.6 MB/s eta 0:00:02
       ------------------------------------- -- 94.9/102.4 MB 5.6 MB/s eta 0:00:02
       ------------------------------------- -- 96.2/102.4 MB 5.6 MB/s eta 0:00:02
       -------------------------------------- - 98.0/102.4 MB 5.6 MB/s eta 0:00:01
       -------------------------------------- - 99.6/102.4 MB 5.7 MB/s eta 0:00:01
       ---------------------------------------  101.4/102.4 MB 5.7 MB/s eta 0:00:01
       ---------------------------------------  102.2/102.4 MB 5.7 MB/s eta 0:00:01
       ---------------------------------------  102.2/102.4 MB 5.7 MB/s eta 0:00:01
       ---------------------------------------- 102.4/102.4 MB 5.6 MB/s  0:00:18
    Downloading graphviz-0.21-py3-none-any.whl (47 kB)
    Installing collected packages: graphviz, catboost
    
       ---------------------------------------- 0/2 [graphviz]
       ---------------------------------------- 0/2 [graphviz]
       ---------------------------------------- 0/2 [graphviz]
       ---------------------------------------- 0/2 [graphviz]
       ---------------------------------------- 0/2 [graphviz]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       -------------------- ------------------- 1/2 [catboost]
       ---------------------------------------- 2/2 [catboost]
    
    Successfully installed catboost-1.2.8 graphviz-0.21
    

    
    [notice] A new release of pip is available: 25.2 -> 25.3
    [notice] To update, run: C:\Users\SMangal\AppData\Local\Microsoft\WindowsApps\PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\python.exe -m pip install --upgrade pip
    


```python
from catboost import CatBoostClassifier

# Use above same Scale_Pos_Weight

# Load model
cb_classifier = CatBoostClassifier(
    iterations = 100,
    learning_rate = 0.1,
    loss_function = 'Logloss',
    eval_metric = 'F1',
    scale_pos_weight = scale_pos_weight,
    random_state = 42,
    verbose = 0
)

# Fit the model
cb_classifier.fit(X_train_scaled, y_train)

# Make Predictions
cb_pred = cb_classifier.predict(X_test_scaled)
cb_prob = cb_classifier.predict_proba(X_test_scaled)[:, 1]

# Get evaluation metrics
print("Confusion Matrix\n", confusion_matrix(y_test, cb_pred))
print("\nClassification Report\n", classification_report(y_test, cb_pred))
print("\nROC-AUC-Score: ",roc_auc_score(y_test, cb_prob))
```

    Confusion Matrix
     [[1270375     506]
     [      2    1641]]
    
    Classification Report
                   precision    recall  f1-score   support
    
               0       1.00      1.00      1.00   1270881
               1       0.76      1.00      0.87      1643
    
        accuracy                           1.00   1272524
       macro avg       0.88      1.00      0.93   1272524
    weighted avg       1.00      1.00      1.00   1272524
    
    
    ROC-AUC-Score:  0.9996824390585994
    

### Observations
- This model is Performing very well interms of managing the Precision, Recall and F1-Score comparing with the Any other models.
- Native handling of categorical features and its innovative "Ordered Boosting" training scheme, which specifically prevents target leakage and reduces overfitting in such data scenarios.
- The Speciality of this CATBoost model is 'it can consider target variable data as a Two Categories like Fraud and non Fraud category'
- Due to this reason, we can see CATBoost model is having the good precision which is having very less 'False Positives' and very less 'False Negitives'
- **We can say ADABoost is a Hero model for our JP Morgan and Chase Fraud Detection Project**

> #### We are increasing the iterations count from 100 to 200 and then 200 to 300. This below code is Optional, because it is Increasing the count of 'False Negitives'. You can understand this by comparing the Three iterations (100, 200, and 300) and Cofusion Matrix Outputs.


```python
# Now we can increase iterations from 100 to 200

# Load model
cb_classifier = CatBoostClassifier(
    iterations = 200,
    learning_rate = 0.1,
    loss_function = 'Logloss',
    eval_metric = 'F1',
    scale_pos_weight = scale_pos_weight,
    random_state = 42,
    verbose = 0
)

# Fit the model
cb_classifier.fit(X_train_scaled, y_train)

# Make predictions
cb_pred = cb_classifier.predict(X_test_scaled)
cb_prob = cb_classifier.predict_proba(X_test_scaled)[:, 1]

# Get evaluation metrics
print("Confusion Matrix\n", confusion_matrix(y_test, cb_pred))
print("\nClassification Report\n", classification_report(y_test, cb_pred))
print("Roc-Auc score\n", roc_auc_score(y_test, cb_prob))
```

    Confusion Matrix
     [[1270480     401]
     [      3    1640]]
    
    Classification Report
                   precision    recall  f1-score   support
    
               0       1.00      1.00      1.00   1270881
               1       0.80      1.00      0.89      1643
    
        accuracy                           1.00   1272524
       macro avg       0.90      1.00      0.95   1272524
    weighted avg       1.00      1.00      1.00   1272524
    
    Roc-Auc score
     0.999630339199814
    


```python
# Now we can increase iterations from 200 to 300

# Load model
cb_classifier = CatBoostClassifier(
    iterations = 300,
    learning_rate = 0.1,
    loss_function = 'Logloss',
    eval_metric = 'F1',
    scale_pos_weight = scale_pos_weight,
    random_state = 42,
    verbose = 0
)

# Fit the model
cb_classifier.fit(X_train_scaled, y_train)

# Make predictions
cb_pred = cb_classifier.predict(X_test_scaled)
cb_prob = cb_classifier.predict_proba(X_test_scaled)[:, 1]

# Get evaluation metrics
print("Confusion Matrix\n", confusion_matrix(y_test, cb_pred))
print("\nClassification Report\n", classification_report(y_test, cb_pred))
print("Roc-Auc score\n", roc_auc_score(y_test, cb_prob))
```

    Confusion Matrix
     [[1270480     401]
     [      3    1640]]
    
    Classification Report
                   precision    recall  f1-score   support
    
               0       1.00      1.00      1.00   1270881
               1       0.80      1.00      0.89      1643
    
        accuracy                           1.00   1272524
       macro avg       0.90      1.00      0.95   1272524
    weighted avg       1.00      1.00      1.00   1272524
    
    Roc-Auc score
     0.999630339199814
    

### Observations
- From the above Two iterations, iterations = 200, and iterations = 300 we can understand Confusion Matrix and Classfication Reports are bring constant, while increasing or decreasing the iterations value

#### The Adaptive Boosting model will take more Computing Resources, due to this it will take more time to Execute the model.
> **Note**: It does not make any Positive impact on model, So you can simply remove this code block or you can neglect this codeblock. Consider this for Just Reference purpose.

> **Caution:** This will take more time to Execute, So do not run this code

### 4.6 AdaBoost (Adaptive Boosting)


```python
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier

# We can define a base estimator
base_estimator = DecisionTreeClassifier(max_depth = 1)

# Load model
ada_classifier = AdaBoostClassifier(
    estimator = base_estimator,
    n_estimators = 100,
    learning_rate = 0.1,
    random_state = 42
)

# Fit the model
ada_classifier.fit(X_train_scaled, y_train)

# Make predictions
ada_pred = ada_classifier.predict(X_test_scaled)
ada_prob = ada_classifier.predict_proba(X_test_scaled)[:, 1]

# Print evaluations metrics
print("Confusion matrix\n", confusion_matrix(y_test, ada_pred))
print("\nClassification Report\n", classification_report(y_test, ada_pred))
print("ROC-AUC-Score\n", roc_auc_score(y_test, ada_prob))
```

### Observations
- The Adaboost is having the very less 'False Positives', this is a good sign, but we can see more number of increasing 'False Negitives'
- We can see AdaBoost is having very less recall comparing with the all the other models. So we can not consider this as a best model

### 4.7 eXtreme Gradient Boosting Model (XGBoost Model)


```python
# Import required modules
import xgboost as xgb
from xgboost import XGBClassifier

# Using same 'Scale_Pos_Weight' which is mentioned above models

# Load model
xgb_model = xgb.XGBClassifier(
    objective = 'binary:logistic',
    eval_metric = 'logloss',
    # use_label_encoder = False, # tis option is revmoed fromthe newer versions.
    scale_pos_weight = scale_pos_weight,
    random_state = 42
)

# Fit the model
xgb_model.fit(X_train_scaled, y_train)

# Make predictions
xgb_pred = xgb_model.predict(X_test_scaled)
xgb_prob = xgb_model.predict_proba(X_test_scaled)[:, 1]

# Model evaluation
print("Confusion Matrix:\n", confusion_matrix(y_test, xgb_pred))
print("\n Classification Report:\n", classification_report(y_test, xgb_pred))
print("\n ROC-AUC Score:", roc_auc_score(y_test, xgb_prob))
```

    Confusion Matrix:
     [[1269994     887]
     [     32    1611]]
    
     Classification Report:
                   precision    recall  f1-score   support
    
               0       1.00      1.00      1.00   1270881
               1       0.64      0.98      0.78      1643
    
        accuracy                           1.00   1272524
       macro avg       0.82      0.99      0.89   1272524
    weighted avg       1.00      1.00      1.00   1272524
    
    
     ROC-AUC Score: 0.9995695980559363
    

### Observations
- Previousely we have see XGBoost model having the 43% Precision only (When we apply SMOTE to the Training dataset).
- This time we have not applied SMOTE. Instead of SMOTE we have used Scale_Pos_Weight to handle the class imbalance.
- From the above confusion matrix and classification report you can notice, Scale_Pos_Weight is way better working the SMOTE solution.
- XGBoost model is also good model, because it have fewer False Positives which is less comparing the above model outputs.

## 5. Unsupervised Machine Learning models

### 5.1 Isolation Forest - We are applying this model on the test data


```python
# Import and Initialize
from sklearn.ensemble import IsolationForest

# Initialize Model
iso_forest = IsolationForest(
    n_estimators = 100,
    max_samples = 'auto',
    contamination = 0.001,
    random_state = 42
)

# Fit on scaled features
iso_forest.fit(X_test_scaled)

# Predict Anomalies
# Predict: -1 = Anomaly, 1 = Normal
y_pred_iso = iso_forest.predict(X_test_scaled)

# Convert to binary: 1 = Fraud, 0 = Non-Fraud
y_pred_iso_binary = [1 if x == -1 else 0 for x in y_pred_iso]

# Evaluate againest true labels
print("Confusion Matrix:\n", confusion_matrix(y_test, y_pred_iso_binary))
print("\nClassification Report:\n", classification_report(y_test, y_pred_iso_binary))

# Save Anomaly scores for Hybrid Model
anomaly_scores = iso_forest.decision_function(X_test_scaled)
```

    Confusion Matrix:
     [[1269625    1256]
     [   1627      16]]
    
    Classification Report:
                   precision    recall  f1-score   support
    
               0       1.00      1.00      1.00   1270881
               1       0.01      0.01      0.01      1643
    
        accuracy                           1.00   1272524
       macro avg       0.51      0.50      0.50   1272524
    weighted avg       1.00      1.00      1.00   1272524
    
    

### Observations
- Isolation Forest model is not performing well, we can understand this by watching the Confusion Matrix. It is having 1000+ False Positives, and it is unable to find the Original Fraud .
- Comparing with the all the other models, Isolation Forest detected very less Actual Fraud Cases (True Positives).
- Unsupervised Machine learning models do not require training data. Due to not having the data training, this model is not performed well.

### 5.2 K-Means clustering - Applying on test data only


```python
# to find optimal k value - we use ELBOW method

# Import required modules
from sklearn.cluster import KMeans

# Extract numeric only columns from DF
num_cols = df.select_dtypes(include = ['number'])

# Elbow method to find optimal K
inertia = []
K = range(1, 11)

for k in K:
    kmeans = KMeans(n_clusters = k, random_state = 42)
    kmeans.fit(X_test_scaled)
    inertia.append(kmeans.inertia_)

# Plot elbow curve
plt.figure(figsize = (8, 6))
plt.plot(K, inertia, marker = 'o')
plt.xlabel('Number of clusters (k)')
plt.ylabel('Inertia')
plt.title("Elbow method for optimal k")
plt.grid(True)
plt.show()
```


    
![png](output_89_0.png)
    



```python
# Apply K-Means
kmeans = KMeans(n_clusters = 5, random_state = 42)
cluster_labels = kmeans.fit_predict(X_test_scaled)

# Combine cluster labels with the true fraud labels
cluster_df = pd.DataFrame(X_test_scaled)
cluster_df['Cluster'] = cluster_labels
cluster_df['isFraud'] = y_test.reset_index(drop = True)

# Fraud count per cluster
fraud_by_cluster = cluster_df.groupby('Cluster')['isFraud'].value_counts().unstack().fillna(0)
print(fraud_by_cluster)
```

    isFraud         0      1
    Cluster                 
    0        462612.0  677.0
    1        550116.0  677.0
    2        204866.0    5.0
    3           992.0    0.0
    4         52295.0  284.0
    

### observations
- To find the Optimal K value we have Plotted Elbow. By using the Elbow method we can understand Ideal number for selecting the number of clusters.
- In the K-means clustering model, we have take numbers of clusters as 5.
- In the output we can see more number of Frauds are occured at the cluster zero, cluster one, and cluster four.
- Due to the groupping the number of clusters based on the number of fraud cases, can be helpful for Hybrid Machine Learning model

> #### **Note**: In this notebook we are not mentioning Auto-Encoder Unsupervised Machine Learning Model, because it demands more computing resources. Thats why we are neglecting this model.

### Now we are doing Hybrid Machine Learning model. For that we are using **CatBoost model**, with the Following machine learning models features as a input

> Decision Tree

> CatBoost

> XGBoost

> Isolation Forest

> K-means Clustering

### 6. Hybrid CATBoost Model


```python
# import modules
from catboost import CatBoostClassifier

# Step1: Create a base features - drop label column and scale features
X_base = num_df.drop(columns = ['isFraud'])
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_base)

# Step2: Decision Tree model
dt_classifier = DecisionTreeClassifier(criterion = 'gini', 
                                       max_depth = 10, 
                                       random_state = 42, 
                                       class_weight = 'balanced')
dt_classifier.fit(X_scaled, num_df['isFraud'])

# Step3: CatBoost Model
cb_classifier = CatBoostClassifier(
    iterations = 100,
    learning_rate = 0.1,
    loss_function = 'Logloss',
    eval_metric = 'F1',
    scale_pos_weight = scale_pos_weight,
    random_state = 42,
    verbose = 0
)
cb_classifier.fit(X_scaled, num_df['isFraud'])

# Step4: XGBoost model
xgb_model = xgb.XGBClassifier(
    objective = 'binary:logistic',
    eval_metric = 'logloss',
    use_label_encoder = False,
    scale_pos_weight = scale_pos_weight,
    random_state = 42
)
xgb_model.fit(X_scaled, num_df['isFraud'])

# Step5: K-Means Clustering
kmeans = KMeans(n_clusters=5, random_state=42, n_init='auto')
cluster_labels = kmeans.fit_predict(X_scaled)

# Step6: Isolation forest
iso_forest = IsolationForest(contamination=0.001, random_state=42)
iso_forest.fit(X_scaled) 
anomaly_scores = iso_forest.decision_function(X_scaled)

# Step7: Combine all features
dt_pred = dt_classifier.predict(X_scaled).reshape(-1, 1)
cb_pred = cb_classifier.predict(X_scaled).reshape(-1, 1)
xgb_pred = xgb_model.predict(X_scaled).reshape(-1, 1)
cluster_labels_reshaped = cluster_labels.reshape(-1, 1)
anomaly_scores_reshaped = anomaly_scores.reshape(-1, 1)

X_hybrid = np.hstack((
    X_scaled,
    dt_pred,
    cb_pred,
    xgb_pred,
    cluster_labels_reshaped,
    anomaly_scores_reshaped
))

y_hybrid = num_df['isFraud'].values

# Step8: the model
X_train, X_test, y_train, y_test = train_test_split(X_hybrid, y_hybrid, test_size = 0.2, random_state = 42, stratify = y_hybrid)

# Step9: Now apply CatBoost model
hybrid_catboost = CatBoostClassifier(
    iterations = 100,
    learning_rate = 0.1,
    loss_function = 'Logloss',
    eval_metric = 'F1',
    scale_pos_weight = scale_pos_weight,
    random_state = 42,
    verbose = 0
)

# Fit model
hybrid_catboost.fit(X_train, y_train)

# Make predictions
hybrid_catboost_pred = hybrid_catboost.predict(X_test)
hybrid_catboost_prob = hybrid_catboost.predict_proba(X_test)[:, 1]

# Evaluation Metrics
print("Confusion matrix\n", confusion_matrix(y_test, hybrid_catboost_pred))
print("\nClassification Report\n", classification_report(y_test, hybrid_catboost_pred))
print("\nROC-AUC-Score\n", roc_auc_score(y_test, hybrid_catboost_prob))
```

    C:\Users\SMangal\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\LocalCache\local-packages\Python313\site-packages\xgboost\training.py:199: UserWarning: [09:42:27] WARNING: C:\actions-runner\_work\xgboost\xgboost\src\learner.cc:790: 
    Parameters: { "use_label_encoder" } are not used.
    
      bst.update(dtrain, iteration=i, fobj=obj)
    

    Confusion matrix
     [[1270719     162]
     [      0    1643]]
    
    Classification Report
                   precision    recall  f1-score   support
    
               0       1.00      1.00      1.00   1270881
               1       0.91      1.00      0.95      1643
    
        accuracy                           1.00   1272524
       macro avg       0.96      1.00      0.98   1272524
    weighted avg       1.00      1.00      1.00   1272524
    
    
    ROC-AUC-Score
     0.9999907519308461
    

### Observations
- The hybrid CatBoost model worked very well. We can understand this while seeing the Confusion Matrix and Classification Report
- **Confusion Matrix**: The Hybrid CatBoost model has detected all the True Positives, it means then model has detected **all the Fraud Transactions**, not even missing the Single Fraud case. It is have a less **False Positives**, not that much (just 357 transactions are being flagged as Fraud, but those transactions are not Fraud, and we can clearly see False Negitives are completely Zero. this is a Good sign.
- In the Classification report we can see Precision is 82% which good, and we have achieved Recall with the 100%. It mean our hybrid model is detected all the Fraud cases accurately.

### **Final Verdict**: 
> #### With the help of **Hybrid Catboost** model we are able to achive 100% recall and able detect all the Fraud Transactions,

### 6.2 Wrap in a Custom Python Class
- Defining a class that stores all models and transformers as its attributes. This allows you to .fit() (on initial training data) and then .predict() (on new or live data) seamlessly.


```python
class HybridFraudPipeline:
    def __init__(self, scaler, dt, cb, xgb, kmeans, iso, hybrid_cb):
        self.scaler = scaler
        self.dt = dt
        self.cb = cb
        self.xgb = xgb
        self.kmeans = kmeans
        self.iso = iso
        self.hybrid_cb = hybrid_cb

    def preprocess(self, X):
        # Drop target if exists
        if 'isFraud' in X.columns:
            X = X.drop(columns=['isFraud'])
        
        # Scale features
        X_scaled = self.scaler.transform(X)
        
        # Generate intermediate model predictions
        dt_pred = self.dt.predict(X_scaled).reshape(-1, 1)
        cb_pred = self.cb.predict(X_scaled).reshape(-1, 1)
        xgb_pred = self.xgb.predict(X_scaled).reshape(-1, 1)
        clusters = self.kmeans.predict(X_scaled).reshape(-1, 1)
        anomaly = self.iso.decision_function(X_scaled).reshape(-1, 1)
        
        # Combine features for hybrid model
        X_hybrid = np.hstack((X_scaled, dt_pred, cb_pred, xgb_pred, clusters, anomaly))
        return X_hybrid

    def predict(self, X):
        X_hybrid = self.preprocess(X)
        return self.hybrid_cb.predict(X_hybrid)
```

### 6.3 Save all models and Transformers
- You must save each model (scaler, tree, CatBoost, XGB, KMeans, Isolation Forest, and final CatBoost) using joblib or pickle after training:


```python
import joblib

joblib.dump(scaler, 'scaler.pkl')
joblib.dump(dt_classifier, 'dt.pkl')
joblib.dump(cb_classifier, 'cb.pkl')
joblib.dump(xgb_model, 'xgb.pkl')
joblib.dump(kmeans, 'kmeans.pkl')
joblib.dump(iso_forest, 'iso.pkl')
joblib.dump(hybrid_catboost, 'hybrid_cb.pkl')
```




    ['hybrid_cb.pkl']



### 7. Save the model Output in CSV/Parquet file


```python
# Save the outputs Parquet file

# 1. Separate Features and target
X_full = num_df.drop(columns = ['isFraud'])
y_full = num_df['isFraud']
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_full)
```


```python
from sklearn.tree import DecisionTreeClassifier
# Step2: Decision Tree model
dt_classifier = DecisionTreeClassifier(criterion = 'gini', max_depth = 10, random_state = 42, class_weight = 'balanced')
# Fit the model
dt_classifier.fit(X_scaled, y_full)
```




<style>#sk-container-id-1 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-1 {
  color: var(--sklearn-color-text);
}

#sk-container-id-1 pre {
  padding: 0;
}

#sk-container-id-1 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-1 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-1 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-1 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-1 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-1 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-1 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-1 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-1 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-1 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-1 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-1 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-1 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-1 div.sk-label label.sk-toggleable__label,
#sk-container-id-1 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-1 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-1 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-1 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-1 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-1 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-1 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-1 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-1 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-1 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>DecisionTreeClassifier(class_weight=&#x27;balanced&#x27;, max_depth=10, random_state=42)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;DecisionTreeClassifier<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.tree.DecisionTreeClassifier.html">?<span>Documentation for DecisionTreeClassifier</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>DecisionTreeClassifier(class_weight=&#x27;balanced&#x27;, max_depth=10, random_state=42)</pre></div> </div></div></div></div>




```python
from catboost import CatBoostClassifier
# Step3: CatBoost Model
cb_classifier = CatBoostClassifier(
    iterations = 100,
    learning_rate = 0.1,
    loss_function = 'Logloss',
    eval_metric = 'F1',
    scale_pos_weight = scale_pos_weight,
    random_state = 42,
    verbose = 0
)
```


```python
import xgboost as xgb
from xgboost import XGBClassifier

# Fit the model
cb_classifier.fit(X_scaled, y_full)

# Step4: XGBoost model
xgb_model = xgb.XGBClassifier(
    objective = 'binary:logistic',
    eval_metric = 'logloss',
    # use_label_encoder = False, # latest version don't need this.
    scale_pos_weight = scale_pos_weight,
    random_state = 42
)
xgb_model.fit(X_scaled, y_full)
```




<style>#sk-container-id-3 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-3 {
  color: var(--sklearn-color-text);
}

#sk-container-id-3 pre {
  padding: 0;
}

#sk-container-id-3 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-3 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-3 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-3 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-3 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-3 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-3 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-3 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-3 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-3 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-3 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-3 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-3 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-3 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-3 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-3 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-3 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-3 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-3 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-3 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-3 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-3 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-3 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-3 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-3 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-3 div.sk-label label.sk-toggleable__label,
#sk-container-id-3 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-3 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-3 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-3 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-3 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-3 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-3 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-3 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-3 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-3 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-3 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-3 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-3 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-3" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>XGBClassifier(base_score=None, booster=None, callbacks=None,
              colsample_bylevel=None, colsample_bynode=None,
              colsample_bytree=None, device=None, early_stopping_rounds=None,
              enable_categorical=False, eval_metric=&#x27;logloss&#x27;,
              feature_types=None, feature_weights=None, gamma=None,
              grow_policy=None, importance_type=None,
              interaction_constraints=None, learning_rate=None, max_bin=None,
              max_cat_threshold=None, max_cat_to_onehot=None,
              max_delta_step=None, max_depth=None, max_leaves=None,
              min_child_weight=None, missing=nan, monotone_constraints=None,
              multi_strategy=None, n_estimators=None, n_jobs=None,
              num_parallel_tree=None, ...)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-3" type="checkbox" checked><label for="sk-estimator-id-3" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;XGBClassifier<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://xgboost.readthedocs.io/en/release_3.0.0/python/python_api.html#xgboost.XGBClassifier">?<span>Documentation for XGBClassifier</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>XGBClassifier(base_score=None, booster=None, callbacks=None,
              colsample_bylevel=None, colsample_bynode=None,
              colsample_bytree=None, device=None, early_stopping_rounds=None,
              enable_categorical=False, eval_metric=&#x27;logloss&#x27;,
              feature_types=None, feature_weights=None, gamma=None,
              grow_policy=None, importance_type=None,
              interaction_constraints=None, learning_rate=None, max_bin=None,
              max_cat_threshold=None, max_cat_to_onehot=None,
              max_delta_step=None, max_depth=None, max_leaves=None,
              min_child_weight=None, missing=nan, monotone_constraints=None,
              multi_strategy=None, n_estimators=None, n_jobs=None,
              num_parallel_tree=None, ...)</pre></div> </div></div></div></div>




```python
from sklearn.cluster import KMeans
# Step5: K-Means Clustering
kmeans = KMeans(n_clusters=5, random_state=42, n_init='auto')
cluster_labels = kmeans.fit_predict(X_scaled)
```


```python
from sklearn.ensemble import IsolationForest
# Step6: Isolation forest
iso_forest = IsolationForest(contamination=0.001, random_state=42)
iso_forest.fit(X_scaled) 
anomaly_scores = iso_forest.decision_function(X_scaled)
```


```python
# Step7: Save the outputs to parquet
df_output = X_full.copy()
```


```python
# Step8: Add the new Hybrid features as a new columns
df_output['dt_pred'] = dt_classifier.predict(X_scaled)
df_output['cb_pred'] = cb_classifier.predict(X_scaled)
df_output['xgb_pred'] = xgb_model.predict(X_scaled)
df_output['cluster_labels'] = cluster_labels
df_output['anomaly_scores'] = anomaly_scores

# Step9: Add the actual Target variable
df_output['isFraud'] = y_full

# Step10: Save the combined Dataframe to Parquet file
df_output.to_parquet("Complete_optimal_fraud_detection_output.parquet", index=False)
print("✅ Final output saved to 'Complete_optimal_fraud_detection_output.parquet'")
```

    ✅ Final output saved to 'Complete_optimal_fraud_detection_output.parquet'
    

## 8. Connect our model output to Real-World-Live data from Azure Blob Storage Account
> **Note**: Do not run the below code, we don't have live data connection from Azure or any other cloud storage service provider

### 8.1 Load the Saved Models


```python
import joblib
import pandas as pd
from azure.storage.blob import BlobServiceClient
import io

# Load saved models and scaler
scaler = joblib.load('scaler.pkl')
dt = joblib.load('dt.pkl')
cb = joblib.load('cb.pkl')
xgb = joblib.load('xgb.pkl')
kmeans = joblib.load('kmeans.pkl')
iso = joblib.load('iso.pkl')
hybrid_cb = joblib.load('hybrid_cb.pkl')

# Define or import the HybridFraudPipeline class from previous step
pipeline = HybridFraudPipeline(scaler, dt, cb, xgb, kmeans, iso, hybrid_cb)
```

### 8.2 Connect to Azure Blob Storage


```python
# Azure Blob Storage connection
connection_string = "your_connection_string"
container_name = "your_container_name"
blob_name = "live_transactions.csv"

try:
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)
    stream = blob_client.download_blob()
    df_live = pd.read_csv(io.BytesIO(stream.readall()))
except Exception as e:
    print(f"Failed to load live data from Azure Blob: {e}")
    raise

# You can skip dropping 'isFraud' here since pipeline handles it, but safe to keep
if 'isFraud' in df_live.columns:
    df_live = df_live.drop(columns=['isFraud'])

# Run prediction on live data through pipeline
predictions = pipeline.predict(df_live)

print(predictions)  # Outputs predicted fraud labels (0/1)
```
