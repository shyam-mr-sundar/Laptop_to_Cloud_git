
-- 1) identify employees with the highest total hours worked and least absenteeism. -- finding top 10 employees
select employeeid, employeename, sum(total_hours) as total_worked_hours, sum(days_present) as total_present_days, sum(days_absent) as total_absent_days
from attendance group by  employeeid, employeename order by total_worked_hours desc, total_absent_days asc limit 10;

-- 2) analyze how training programs improve departmental performance
select e.department_id, t.program_name, t.trainer_name, round(avg(t.feedback_score),2) as avg_feedback_score, sum(t.employeeid) as total_employees_trained
,e.performance_score, Rank() over(partition by e.performance_score) as performance_rating
from training_programs t join employee_details e on t.employeeid = e.employeeid 
group by e.department_id, t.program_name,t.trainer_name,e.performance_score order by e.department_id, avg_feedback_score desc;

-- 3) evaluate the efficiency of project budgets by calculating cost per hour worked
select project_id,project_name, sum(p.project_id/p.hours_worked) as cost_per_hour,
avg(p.hours_worked) over(partition by project_name) as avg_project_hours from project_assignments p group by project_id,project_name order by avg_project_hours desc;

-- 4) measure attendance trends and identify departments with significant deviations
select e.employeeid,e.department_id,e.manager_id,  avg(a.total_hours) as avg_hours_worked, 
avg(a.days_present) as avg_days_present, avg(a.days_absent) as avg_days_absent,
rank() over(partition by e.department_id) as d_ranks
from attendance a join employee_details e on a.employeeid = e.employeeid group by e.manager_id,e.department_id,e.employeeid having avg_days_absent > 4
order by avg_hours_worked desc;

-- 5) Link training technologies with project milestones to assess training impact: since skill column have one two values seprated by comma we can take first and last values and compare.
-- here we are finding training and project success correlation with training complted but milesotnes achieved is only one
with training_skills as (
select *, 
trim(substring_index(t.technologies_covered, ',', 1)) as first_skill,
trim(substring_index(t.technologies_covered, ',', -1)) as last_skill
from training_programs t
),
employee_skills as (
select *, 
trim(substring_index(p.technologies_used, ',', 1)) as first_skill,
trim(substring_index(p.technologies_used, ',', -1)) as last_skill
from project_assignments p
)
select ts.employeeid, ts.employeename, ts.technologies_covered, es.manager_id,ts.department_id,es.technologies_used, es.milestones_achieved,ts.completion_status as 'training_completed ?',
count(ts.employeeid) over(partition by es.employeename)as total_projects_by_employee
from training_skills ts join employee_skills es -- all possible combination for join 
on ts.first_skill = es.last_skill
or ts.last_skill = es.first_skill
or ts.first_skill = es.first_skill
or ts.last_skill = es.last_skill
where es.milestones_achieved <= 1 and ts.completion_status = 'completed'  order by es.employeename desc;


-- 6) identify employees contributing to high-budget projects with excellent performance:

select e.employeeid, e.employeename, e.performance_score, p.project_name, p.budget from employee_details e join project_assignments p on e.employeeid = p.employeeid
where e.performance_score = 'excellent' and p.budget > (select avg(budget) from project_assignments) order by p.budget desc, e.performance_score desc;

-- 7) Identify employees who have undergone training in specific technologies and contributed to high performing projects using those technologies.
-- here we are taking employees who are not completed the training and have 9 milesstore or more achieved.
with training_skills as (
select *, 
trim(substring_index(t.technologies_covered, ',', 1)) as first_skill,
trim(substring_index(t.technologies_covered, ',', -1)) as last_skill
from training_programs t
),
employee_skills as (
select *, 
trim(substring_index(p.technologies_used, ',', 1)) as first_skill,
trim(substring_index(p.technologies_used, ',', -1)) as last_skill
from project_assignments p
)
select ts.employeeid, ts.employeename, ts.technologies_covered, es.manager_id,ts.department_id,es.technologies_used, es.milestones_achieved,ts.completion_status as 'training_completed ?',
count(ts.employeeid) over(partition by es.employeename)as total_projects_by_employee
from training_skills ts join employee_skills es -- joins are clubbed between first skill and second skill matching in project and training.
on (ts.first_skill = es.last_skill
and ts.last_skill = es.first_skill)
or (ts.first_skill = es.first_skill
and ts.last_skill = es.last_skill)
where es.milestones_achieved >= 9 and ts.completion_status != 'completed'  order by es.employeename desc;

